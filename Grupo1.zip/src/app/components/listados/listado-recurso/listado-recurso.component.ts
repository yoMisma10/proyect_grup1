import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listado-recurso',
  templateUrl: './listado-recurso.component.html',
  styleUrls: ['./listado-recurso.component.css']
})
export class ListadoRecursoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
