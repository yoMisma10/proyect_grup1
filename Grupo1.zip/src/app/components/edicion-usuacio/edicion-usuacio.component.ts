import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edicion-usuacio',
  templateUrl: './edicion-usuacio.component.html',
  styleUrls: ['./edicion-usuacio.component.css']
})
export class EdicionUsuacioComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
