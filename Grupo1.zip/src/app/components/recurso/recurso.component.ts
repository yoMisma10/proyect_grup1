import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recurso',
  templateUrl: './recurso.component.html',
  styleUrls: ['./recurso.component.css']
})
export class RecursoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
