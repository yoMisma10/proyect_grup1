import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detalle-recurso',
  templateUrl: './detalle-recurso.component.html',
  styleUrls: ['./detalle-recurso.component.css']
})
export class DetalleRecursoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
